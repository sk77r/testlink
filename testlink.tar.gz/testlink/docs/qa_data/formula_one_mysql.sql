/* Password for all users: 'star trek' */
INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Mark.Webber','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Mark.Webber@formulaone.com','Mark','Webber','en_GB',1,'DEVKEY-Webber',12345678);

INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Lewis.Hamilton','9651cbc7c0b5fb1a81f2858a07813c82',9,
            'Lewis.Hamilton@formulaone.com','Lewis','Hamilton','it_IT',1,'DEVKEY-Hamilton',123456789);

INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Fernando.Alonso','9651cbc7c0b5fb1a81f2858a07813c82',6,
            'Fernando.Alonso@formulaone.com','Fernando','Alonso','en_GB',1,'DEVKEY-Alonso',123456780);


INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Jenson.Button','9651cbc7c0b5fb1a81f2858a07813c82',6,
            'Jenson.Button@formulaone.com','Jenson','Button','en_GB',1,'DEVKEY-Button',012345678);
 
INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Sebastian.Vettel','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Sebastian.Vettel@formulaone.com','Sebastian','Vettel','en_GB',1,'DEVKEY-Vettel',8812345678);


INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Felipe.Massa','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Felipe.Massa@formulaone.com','Felipe','Massa','en_GB',1,'DEVKEY-Massa',12345678909);


INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Nico.Rosberg','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Nico.Rosberg@formulaone.com','Nico','Rosberg','en_GB',1,'DEVKEY-Rosberg',8181812345678);


INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Robert.Kubica','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Robert.Kubica@formulaone.com','Robert','Kubica','en_GB',1,'DEVKEY-Kubica',6000123);


INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Michael.Schumacher','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Michael.Schumacher@formulaone.com','Michael','Schumacher','en_GB',1,'DEVKEY-Schumacher',029312345678);


INSERT INTO tl_users(
            login, password, role_id, email, first, last, locale,active, script_key,cookie_string)
    VALUES ('Adrian.Sutil','9651cbc7c0b5fb1a81f2858a07813c82',8,
            'Adrian.Sutil@formulaone.com','Adrian','Sutil','en_GB',1,'DEVKEY-Sutil',9087612345678);

 